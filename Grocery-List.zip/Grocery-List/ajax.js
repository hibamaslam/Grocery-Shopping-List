function getList()
{
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if ( this.readyState == 4 && this.status == 200)
        {
           var myObj = this.responseText;
           var products = JSON.parse(myObj);
           var table =  "<caption><b>SHOPPING LIST<b></caption>" + "<tr> <th>Serial No:</th> <th>Name</th> <th>Quantity</th> <th>Unit</th> <th>Department</th> <th>Notes</th> </tr>";
            for (var i=0;i<products.length;i++ )
            {
                table += "<tr><td>" +
                 products[i].serialno + "</td><td>" + 
                 products[i].name + "</td><td>" +
                 products[i].quantity + "</td><td>" +
                 products[i].unit + "</td><td>" +
                 products[i].department + "</td><td>" +
                 products[i].notes + "</td></tr>";
            
            }
            document.getElementById('display').innerHTML = table;
            document.getElementById('btn').style.visibility = "hidden";
            document.getElementById('content-container').removeAttribute("id");
         }
    };
    xhttp.open('GET',"list.json",true);
    xhttp.send();

}